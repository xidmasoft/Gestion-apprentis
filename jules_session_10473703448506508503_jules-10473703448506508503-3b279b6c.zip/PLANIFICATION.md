# Document de Planification - GESTION APPRENANTS

## 1. Objectifs
L'objectif général du projet "GESTION APPRENANTS" est de créer une application web intuitive et performante permettant au personnel autorisé d'un Centre de Formation Professionnelle et Technique de gérer efficacement l'ensemble des dossiers des apprenants.

L'application vise principalement à dématérialiser et centraliser :
- L'enregistrement et le suivi des apprenants.
- La gestion de la structure académique (filières, niveaux, années de formation).
- L'accès rapide aux informations via des outils de recherche et de filtrage.

## 2. Périmètre (Scope)
Pour la version 1 (V1), le périmètre est volontairement restreint à la gestion administrative de base des apprenants et de la structure de l'établissement (CRUD de base). Les aspects financiers, pédagogiques et de communication avancée sont exclus de cette première phase.

## 3. Fonctionnalités V1
La V1 doit impérativement intégrer les fonctionnalités suivantes :
- **Gestion des apprenants** : Création, lecture, mise à jour, suppression (CRUD) des dossiers des apprenants.
- **Gestion des filières** : CRUD des différentes filières proposées par le centre.
- **Gestion des niveaux** : CRUD des niveaux d'études.
- **Gestion des années de formation** : CRUD des années académiques/de formation.
- **Gestion des statuts des apprenants** : Suivi du statut de chaque apprenant (ex: actif, diplômé, abandon, etc.).
- **Recherche** : Outil de recherche textuelle pour retrouver rapidement un ou plusieurs apprenants.
- **Filtres** : Capacité à filtrer la liste des apprenants (par filière, niveau, année, statut, etc.).

## 4. Fonctionnalités futures (Hors périmètre V1)
Les éléments suivants ne seront pas développés pour l'instant et feront l'objet de versions ultérieures :
- Gestion des paiements et de la comptabilité.
- Gestion des absences et des retards.
- Gestion des notes et des bulletins.
- Organisation et suivi des examens.
- Authentification et gestion des droits d'accès avancés.
- Système de notifications (email, SMS, etc.).
- Application mobile native (iOS/Android).

## 5. Contraintes techniques
Le projet doit respecter les contraintes technologiques suivantes :
- **Langages et Technologies Web** : HTML5, CSS3.
- **JavaScript** : Utilisation de jQuery, AJAX et JSON (aucun framework JS type React, Vue ou Angular).
- **Backend** : PHP 8+ (sans framework type Laravel ou Symfony).
- **Base de données** : MySQL 8+.
- **Accès aux données** : Utilisation exclusive de PDO (PHP Data Objects).

## 6. Risques
- **Sécurité** : Étant donné l'absence de framework (et donc de protections intégrées par défaut), le risque de failles classiques (injections SQL, XSS, CSRF) est accru. Une attention particulière devra être portée à la sécurisation du code, notamment via PDO et la validation stricte des entrées/sorties.
- **Maintenabilité** : Le développement "from scratch" en PHP/JS sans structure de framework peut conduire à un code spaghetti si une architecture claire (ex: MVC simplifié) n'est pas adoptée dès le départ.
- **Adoption** : Si l'interface (bien que développée sans framework CSS complet ou avec CSS3 pur) n'est pas suffisamment ergonomique, les utilisateurs pourraient être réticents à adopter le nouvel outil.

## 7. Dépendances
- Infrastructure serveur supportant PHP 8+ et MySQL 8+.
- Disponibilité des bibliothèques externes requises de manière ponctuelle (jQuery).
- Accès aux informations et règles de gestion précises du centre de formation pour modéliser correctement la base de données.

## 8. Livrables
- Le code source complet de l'application web (V1).
- Le script SQL de création de la base de données (schéma et données de base/tests).
- Un fichier `README.md` documentant l'installation et la configuration du projet.
- Ce document de planification (et les documents d'analyse à venir).

## 9. Critères de fin de la V1
La V1 sera considérée comme terminée et prête à être livrée lorsque :
- Toutes les fonctionnalités listées dans la section 3 (CRUD, recherche, filtres) sont développées, fonctionnelles et sans bug bloquant.
- Le code respecte les contraintes techniques imposées (PHP 8+, MySQL 8+, pas de framework PHP/JS).
- L'interface utilisateur est opérationnelle (HTML5/CSS3/jQuery).
- L'application est capable de tourner sur un environnement serveur standard sans erreurs.
