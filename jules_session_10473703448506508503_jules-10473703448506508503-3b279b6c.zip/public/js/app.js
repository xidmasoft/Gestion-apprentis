$(document).ready(function() {
    const apiBase = '../api';

    // Initialisation
    loadReferences();
    loadApprenants();
    loadStats();

    // Event Listeners
    $('#btn-add').click(() => openModal());
    $('.close-btn').click(() => $('.modal').addClass('hidden'));
    
    $('#search, #filter-filiere, #filter-niveau, #filter-annee').on('input change', function() {
        loadApprenants();
    });

    $('#form-apprenant').submit(function(e) {
        e.preventDefault();
        saveApprenant();
    });

    // Fonctions
    function showToast(message, type = 'success') {
        const toast = $('#toast');
        toast.text(message).removeClass('hidden success error').addClass(type);
        setTimeout(() => toast.addClass('hidden'), 3000);
    }

    function loadReferences() {
        $.get(`${apiBase}/filieres.php`, data => {
            let options = '<option value="">Toutes les filières</option>';
            data.forEach(f => options += `<option value="${f.id}">${f.nom}</option>`);
            $('#filter-filiere, #filiere_id').html(options);
        });
        $.get(`${apiBase}/niveaux.php`, data => {
            let options = '<option value="">Tous les niveaux</option>';
            data.forEach(n => options += `<option value="${n.id}">${n.nom}</option>`);
            $('#filter-niveau, #niveau_id').html(options);
        });
        $.get(`${apiBase}/annees-formation.php`, data => {
            let options = '<option value="">Toutes les années</option>';
            data.forEach(a => options += `<option value="${a.id}">${a.libelle}</option>`);
            $('#filter-annee, #annee_id').html(options);
        });
    }

    function loadStats() {
        $.get(`${apiBase}/apprenants.php?stats=1`, data => {
            $('#stat-total').text(data.total);
            let details = '';
            data.by_statut.forEach(s => details += `<span style="margin-left:15px">${s.statut}: ${s.count}</span>`);
            $('#stat-details').html(details);
        });
    }

    function loadApprenants() {
        const search = $('#search').val();
        const filiere_id = $('#filter-filiere').val();
        const niveau_id = $('#filter-niveau').val();
        const annee_id = $('#filter-annee').val();
        
        const escapeHTML = (str) => {
            if (str === null || str === undefined) return '';
            return String(str).replace(/[&<>'"]/g, match => {
                return { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[match];
            });
        };

        $.get(`${apiBase}/apprenants.php`, { search, filiere_id, niveau_id, annee_id }, function(data) {
            let rows = '';
            data.forEach(a => {
                rows += `<tr>
                    <td>${escapeHTML(a.matricule)}</td>
                    <td>${escapeHTML(a.nom)}</td>
                    <td>${escapeHTML(a.prenom)}</td>
                    <td>${escapeHTML(a.filiere)}</td>
                    <td>${escapeHTML(a.niveau)}</td>
                    <td>${escapeHTML(a.statut)}</td>
                    <td>
                        <button onclick="viewApprenant(${a.id})">Détails</button>
                        <button onclick="editApprenant(${a.id})">Modifier</button>
                        <button class="btn-danger" onclick="deleteApprenant(${a.id})">Supprimer</button>
                    </td>
                </tr>`;
            });
            $('#apprenants-table tbody').html(rows);
        });
    }

    function saveApprenant() {
        const formData = {
            id: $('#apprenant-id').val(),
            action: $('#form-action').val(),
            matricule: $('#matricule').val(),
            nom: $('#nom').val(),
            prenom: $('#prenom').val(),
            date_naissance: $('#date_naissance').val(),
            sexe: $('input[name="sexe"]:checked').val(),
            telephone: $('#telephone').val(),
            adresse: $('#adresse').val(),
            filiere_id: $('#filiere_id').val(),
            niveau_id: $('#niveau_id').val(),
            annee_id: $('#annee_id').val(),
            statut: $('#statut').val()
        };

        const method = formData.id ? 'PUT' : 'POST';

        $.ajax({
            url: `${apiBase}/apprenants.php`,
            type: method,
            contentType: 'application/json',
            data: JSON.stringify(formData),
            success: function(res) {
                if(res.success) {
                    showToast(res.message);
                    $('#modal-apprenant').addClass('hidden');
                    loadApprenants();
                    loadStats();
                }
            },
            error: function(xhr) {
                const res = JSON.parse(xhr.responseText);
                showToast(res.error || "Une erreur est survenue", 'error');
            }
        });
    }

    window.openModal = function() {
        $('#form-apprenant')[0].reset();
        $('#apprenant-id').val('');
        $('#form-action').val('create');
        $('#modal-title').text('Ajouter un apprenant');
        $('#modal-apprenant').removeClass('hidden');
    }

    window.editApprenant = function(id) {
        $.get(`${apiBase}/apprenants.php?id=${id}`, function(data) {
            $('#apprenant-id').val(data.id);
            $('#form-action').val('update');
            $('#matricule').val(data.matricule);
            $('#nom').val(data.nom);
            $('#prenom').val(data.prenom);
            $('#date_naissance').val(data.date_naissance);
            $(`input[name="sexe"][value="${data.sexe}"]`).prop('checked', true);
            $('#telephone').val(data.telephone);
            $('#adresse').val(data.adresse);
            $('#filiere_id').val(data.filiere_id);
            $('#niveau_id').val(data.niveau_id);
            $('#annee_id').val(data.annee_id);
            $('#statut').val(data.statut);
            
            $('#modal-title').text('Modifier un apprenant');
            $('#modal-apprenant').removeClass('hidden');
        });
    }

    window.viewApprenant = function(id) {
        const escapeHTML = (str) => {
            if (str === null || str === undefined) return '';
            return String(str).replace(/[&<>'"]/g, match => {
                return { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[match];
            });
        };

        $.get(`${apiBase}/apprenants.php?id=${id}`, function(data) {
            const html = `
                <p><strong>Matricule:</strong> ${escapeHTML(data.matricule)}</p>
                <p><strong>Nom:</strong> ${escapeHTML(data.nom)}</p>
                <p><strong>Prénom:</strong> ${escapeHTML(data.prenom)}</p>
                <p><strong>Date de naissance:</strong> ${escapeHTML(data.date_naissance)}</p>
                <p><strong>Sexe:</strong> ${escapeHTML(data.sexe)}</p>
                <p><strong>Téléphone:</strong> ${escapeHTML(data.telephone)}</p>
                <p><strong>Adresse:</strong> ${escapeHTML(data.adresse)}</p>
                <p><strong>Filière:</strong> ${escapeHTML(data.filiere_nom)}</p>
                <p><strong>Niveau:</strong> ${escapeHTML(data.niveau_nom)}</p>
                <p><strong>Année:</strong> ${escapeHTML(data.annee_libelle)}</p>
                <p><strong>Statut:</strong> ${escapeHTML(data.statut)}</p>
            `;
            $('#details-content').html(html);
            $('#modal-details').removeClass('hidden');
        });
    }

    window.deleteApprenant = function(id) {
        if(confirm("Voulez-vous vraiment supprimer cet apprenant ?")) {
            $.ajax({
                url: `${apiBase}/apprenants.php`,
                type: 'DELETE',
                contentType: 'application/json',
                data: JSON.stringify({id: id}),
                success: function(res) {
                    showToast(res.message);
                    loadApprenants();
                    loadStats();
                }
            });
        }
    }
});