<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Apprenants</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
</head>
<body>
    <header>
        <h1>Gestion Apprenants</h1>
        <button id="btn-add">Nouvel Apprenant</button>
    </header>

    <main>
        <div id="toast" class="toast hidden"></div>

        <section class="stats">
            <div class="stat-card">Total Apprenants: <span id="stat-total">0</span></div>
            <div id="stat-details"></div>
        </section>

        <section class="toolbar">
            <input type="text" id="search" placeholder="Rechercher par nom, prénom ou matricule...">
            <select id="filter-filiere"><option value="">Toutes les filières</option></select>
            <select id="filter-niveau"><option value="">Tous les niveaux</option></select>
            <select id="filter-annee"><option value="">Toutes les années</option></select>
        </section>

        <table id="apprenants-table">
            <thead>
                <tr>
                    <th>Matricule</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Filière</th>
                    <th>Niveau</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <!-- Contenu injecté via AJAX -->
            </tbody>
        </table>
    </main>

    <!-- Modale Formulaire Apprenant -->
    <div id="modal-apprenant" class="modal hidden">
        <div class="modal-content">
            <span class="close-btn">&times;</span>
            <h2 id="modal-title">Ajouter un apprenant</h2>
            <form id="form-apprenant">
                <input type="hidden" id="apprenant-id" name="id">
                <input type="hidden" id="form-action" name="action" value="create">
                
                <div class="form-group">
                    <label>Matricule :</label>
                    <input type="text" id="matricule" name="matricule" placeholder="Laisser vide pour générer" readonly>
                </div>
                
                <div class="form-group">
                    <label>Nom :*</label>
                    <input type="text" id="nom" name="nom" required>
                </div>
                
                <div class="form-group">
                    <label>Prénom :*</label>
                    <input type="text" id="prenom" name="prenom" required>
                </div>
                
                <div class="form-group">
                    <label>Date de Naissance :*</label>
                    <input type="date" id="date_naissance" name="date_naissance" required>
                </div>
                
                <div class="form-group">
                    <label>Sexe :*</label>
                    <label><input type="radio" name="sexe" value="M" checked> M</label>
                    <label><input type="radio" name="sexe" value="F"> F</label>
                </div>
                
                <div class="form-group">
                    <label>Téléphone :</label>
                    <input type="text" id="telephone" name="telephone" pattern="[0-9]{10}">
                </div>
                
                <div class="form-group">
                    <label>Adresse :</label>
                    <textarea id="adresse" name="adresse"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Filière :*</label>
                    <select id="filiere_id" name="filiere_id" required></select>
                </div>
                
                <div class="form-group">
                    <label>Niveau :*</label>
                    <select id="niveau_id" name="niveau_id" required></select>
                </div>
                
                <div class="form-group">
                    <label>Année :*</label>
                    <select id="annee_id" name="annee_id" required></select>
                </div>
                
                <div class="form-group">
                    <label>Statut :</label>
                    <select id="statut" name="statut">
                        <option value="Actif">Actif</option>
                        <option value="Abandon">Abandon</option>
                        <option value="Diplômé">Diplômé</option>
                    </select>
                </div>
                
                <button type="submit">Enregistrer</button>
            </form>
        </div>
    </div>
    
    <!-- Modale Détails -->
    <div id="modal-details" class="modal hidden">
        <div class="modal-content">
            <span class="close-btn" onclick="document.getElementById('modal-details').classList.add('hidden')">&times;</span>
            <h2>Détails Apprenant</h2>
            <div id="details-content"></div>
        </div>
    </div>

    <script src="js/app.js"></script>
</body>
</html>
