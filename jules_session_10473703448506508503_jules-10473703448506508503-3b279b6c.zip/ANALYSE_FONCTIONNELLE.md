# Document d'Analyse Fonctionnelle - GESTION APPRENANTS (V1)

## 1. Acteurs
Pour la version 1, deux rôles distincts sont identifiés :
- **Administrateur** : Super-utilisateur ayant accès à l'ensemble du système. Il configure les référentiels (filières, niveaux, années de formation) et gère la totalité des données.
- **Gestionnaire (Personnel chargé de la gestion des apprenants)** : Utilisateur dédié à l'enregistrement et au suivi des apprenants. Il gère les dossiers des apprenants mais n'a pas la possibilité de modifier la structure de base du système (ne peut pas créer ou supprimer des filières, niveaux ou années).

## 2. Cas d'utilisation
- **Pour l'Administrateur :**
  - Gérer les filières (Créer, Lire, Modifier, Désactiver).
  - Gérer les niveaux (Créer, Lire, Modifier, Supprimer).
  - Gérer les années de formation (Créer, Lire, Modifier, Supprimer).
  - Accéder à toutes les fonctionnalités du Gestionnaire.
- **Pour le Gestionnaire :**
  - Gérer les apprenants (Créer, Lire, Modifier, Supprimer).
  - Consulter les détails d'un apprenant.
  - Rechercher des apprenants.
  - Filtrer la liste des apprenants.

## 3. Fonctionnalités
### 3.1. Gestion des Apprenants
- **Ajouter** : Formulaire de création d'un nouveau dossier apprenant.
- **Consulter / Détails** : Affichage d'une fiche complète avec toutes les informations d'un apprenant.
- **Modifier** : Édition des informations d'un apprenant existant.
- **Supprimer** : Retrait d'un apprenant du système (voir "Règles métier" pour la gestion de la suppression).
- **Rechercher** : Champ de recherche multicritère (par nom, prénom, matricule).
- **Filtrer** : Listes déroulantes pour affiner l'affichage (par filière, niveau, année, statut).

### 3.2. Gestion des Filières
- **Ajouter** : Création d'une nouvelle filière.
- **Consulter** : Liste des filières existantes.
- **Modifier** : Changement du libellé ou des détails d'une filière.
- **Désactiver** : Au lieu de supprimer une filière ayant des apprenants, elle peut être désactivée pour qu'elle ne soit plus proposée à l'avenir.

### 3.3. Gestion des Niveaux
- **Gestion du référentiel** : CRUD (Création, Lecture, Modification, Suppression) pour gérer les différents niveaux (ex : CAP, BEP, Attestation).

### 3.4. Gestion des Années de formation
- **Gestion du référentiel** : CRUD pour gérer les années académiques (ex : 2026-2027, 2027-2028).

## 4. Règles métier
- **Matricule unique** : Le système doit garantir qu'il n'y ait pas deux apprenants avec le même matricule.
- **Champs obligatoires** : Lors de la création/modification d'un apprenant, la filière, le niveau et l'année de formation sont obligatoires.
- **Validation des données** : 
  - Date de naissance valide (âge cohérent).
  - Format du téléphone valide.
  - Toutes les entrées doivent être validées côté client (HTML/JS) et côté serveur (PHP).
- **Gestion des suppressions (Intégrité référentielle)** :
  - **Apprenants** : La suppression d'un apprenant entraîne la perte de son dossier. (À confirmer s'il s'agit d'une suppression logique ou physique).
  - **Filières/Niveaux/Années** : Interdiction de supprimer physiquement une filière, un niveau ou une année si des apprenants y sont rattachés. Une désactivation (suppression logique) doit être privilégiée.
- **Gestion des données historiques** : Les apprenants des années précédentes doivent rester consultables.

## 5. Données
Les données nécessaires pour un apprenant sont :
- **Matricule** (Identifiant unique, chaîne de caractères)
- **Nom** (Chaîne de caractères)
- **Prénom** (Chaîne de caractères)
- **Date de naissance** (Date)
- **Sexe** (Caractère ou chaîne : M/F)
- **Téléphone** (Chaîne de caractères)
- **Adresse** (Texte)
- **Filière** (Clé étrangère vers la table des filières)
- **Niveau** (Clé étrangère vers la table des niveaux)
- **Année de formation** (Clé étrangère vers la table des années)
- **Statut** (Chaîne de caractères ou enum : ex. Actif, Abandon, Diplômé)

## 6. Contraintes
- Application web accessible via un navigateur moderne.
- Interfaces développées sans framework JS (jQuery autorisé).
- Backend en PHP natif sans framework (Laravel/Symfony exclus).
- Interfaçage avec MySQL via PDO.

## 7. Exigences de sécurité
- Prévention des injections SQL via l'utilisation systématique de requêtes préparées (PDO).
- Prévention des failles XSS en échappant toutes les données affichées (ex: `htmlspecialchars`).
- Protection contre les attaques CSRF sur les formulaires critiques (ajout de tokens).
- Validation stricte des données côté serveur, peu importe les validations côté client.

## 8. Exigences de performance
- Les recherches et le filtrage doivent être fluides et rapides (utilisation potentielle d'AJAX pour recharger la liste sans rafraîchir toute la page).
- Indexation des champs de recherche fréquents (matricule, nom) dans la base de données MySQL.

## 9. Exigences d'ergonomie
- Interface claire, épurée et intuitive.
- Les actions destructrices (comme la suppression) doivent requérir une confirmation explicite.
- Le retour visuel des actions (succès, erreurs de validation) doit être immédiat et lisible.

## 10. Critères d'acceptation
- L'Administrateur peut configurer les filières (les créer et les désactiver).
- L'Administrateur peut gérer les niveaux et années de formation.
- Le Gestionnaire (et l'Administrateur) peut créer, lire, modifier, et supprimer des dossiers d'apprenants, avec tous les champs requis.
- Lors de la création d'un apprenant, une erreur est renvoyée si le matricule existe déjà ou si les champs obligatoires sont manquants.
- Les outils de recherche et de filtres retournent les bons apprenants correspondant aux critères.
- Aucune anomalie de sécurité majeure n'est détectée.

---

## ⚠️ Ambiguïtés et décisions métier à valider :
1. **Génération du matricule** : Le matricule est-il généré automatiquement par le système selon une règle précise (ex: Année + ID), ou est-il saisi manuellement par l'utilisateur ?
2. **Suppression des apprenants** : S'agit-il d'une suppression physique en base de données ou d'une suppression logique (archivage/changement de statut) ?
3. **Statut des apprenants** : Faut-il définir une liste fixe de statuts dès la V1 (ex: Actif, En attente, Diplômé, Abandon), ou s'agit-il d'un champ libre / gérable par l'Administrateur ?
4. **Authentification** : Bien que "l'authentification avancée" soit hors périmètre, une authentification basique est-elle requise en V1 pour différencier l'Administrateur du Gestionnaire, ou doit-on simplement prévoir l'architecture pour le futur ?