CREATE DATABASE IF NOT EXISTS gestion_apprenants CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gestion_apprenants;

CREATE TABLE IF NOT EXISTS filieres (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    description TEXT,
    actif BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS niveaux (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    description TEXT,
    actif BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS annees_formation (
    id INT AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(50) NOT NULL,
    date_debut DATE,
    date_fin DATE,
    actif BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS apprenants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    matricule VARCHAR(50) NOT NULL UNIQUE,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    date_naissance DATE NOT NULL,
    sexe CHAR(1) NOT NULL,
    telephone VARCHAR(20),
    adresse TEXT,
    filiere_id INT NOT NULL,
    niveau_id INT NOT NULL,
    annee_id INT NOT NULL,
    statut VARCHAR(50) DEFAULT 'Actif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (filiere_id) REFERENCES filieres(id) ON DELETE RESTRICT,
    FOREIGN KEY (niveau_id) REFERENCES niveaux(id) ON DELETE RESTRICT,
    FOREIGN KEY (annee_id) REFERENCES annees_formation(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Données initiales
INSERT INTO filieres (nom, description) VALUES 
('Développement Web', 'Formation fullstack'),
('Réseaux et Télécoms', 'Administration système et réseau'),
('Design Graphique', 'UI/UX et identité visuelle');

INSERT INTO niveaux (nom, description) VALUES 
('BTS', 'Brevet de Technicien Supérieur'),
('Licence', 'Niveau Bac+3'),
('Master', 'Niveau Bac+5');

INSERT INTO annees_formation (libelle, date_debut, date_fin) VALUES 
('2025-2026', '2025-09-01', '2026-06-30'),
('2026-2027', '2026-09-01', '2027-06-30');

INSERT INTO apprenants (matricule, nom, prenom, date_naissance, sexe, telephone, adresse, filiere_id, niveau_id, annee_id, statut) VALUES
('MAT2026001', 'Dupont', 'Jean', '2000-05-15', 'M', '0102030405', 'Paris', 1, 1, 1, 'Actif'),
('MAT2026002', 'Martin', 'Sophie', '2001-08-22', 'F', '0607080910', 'Lyon', 2, 2, 2, 'Actif');
