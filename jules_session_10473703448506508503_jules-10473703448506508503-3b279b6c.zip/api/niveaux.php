<?php
header('Content-Type: application/json');
require_once '../config/database.php';

try {
    $db = getDBConnection();
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $stmt = $db->query("SELECT id, nom FROM niveaux WHERE actif = 1");
        $niveaux = $stmt->fetchAll();
        echo json_encode($niveaux);
    } else {
        http_response_code(405);
        echo json_encode(['error' => 'Méthode non autorisée']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur serveur: ' . $e->getMessage()]);
}
