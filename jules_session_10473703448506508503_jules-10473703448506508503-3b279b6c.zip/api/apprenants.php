<?php
header('Content-Type: application/json');
require_once '../config/database.php';

$db = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            if (isset($_GET['stats'])) {
                $stmt = $db->query("SELECT COUNT(*) as total FROM apprenants");
                $total = $stmt->fetch()['total'];
                $stmt = $db->query("SELECT statut, COUNT(*) as count FROM apprenants GROUP BY statut");
                $by_statut = $stmt->fetchAll();
                echo json_encode(['total' => $total, 'by_statut' => $by_statut]);
                break;
            }
            if (isset($_GET['id'])) {
                // Détails
                $stmt = $db->prepare("SELECT a.*, f.nom as filiere_nom, n.nom as niveau_nom, y.libelle as annee_libelle 
                                      FROM apprenants a 
                                      JOIN filieres f ON a.filiere_id = f.id 
                                      JOIN niveaux n ON a.niveau_id = n.id 
                                      JOIN annees_formation y ON a.annee_id = y.id 
                                      WHERE a.id = ?");
                $stmt->execute([$_GET['id']]);
                echo json_encode($stmt->fetch() ?: []);
            } else {
                // Liste + recherche + filtres
                $query = "SELECT a.id, a.matricule, a.nom, a.prenom, f.nom as filiere, n.nom as niveau, a.statut 
                          FROM apprenants a 
                          JOIN filieres f ON a.filiere_id = f.id 
                          JOIN niveaux n ON a.niveau_id = n.id 
                          WHERE 1=1";
                $params = [];
                
                if (!empty($_GET['search'])) {
                    $query .= " AND (a.nom LIKE ? OR a.prenom LIKE ? OR a.matricule LIKE ?)";
                    $search = "%" . $_GET['search'] . "%";
                    array_push($params, $search, $search, $search);
                }
                if (!empty($_GET['filiere_id'])) {
                    $query .= " AND a.filiere_id = ?";
                    $params[] = $_GET['filiere_id'];
                }
                if (!empty($_GET['niveau_id'])) {
                    $query .= " AND a.niveau_id = ?";
                    $params[] = $_GET['niveau_id'];
                }
                if (!empty($_GET['annee_id'])) {
                    $query .= " AND a.annee_id = ?";
                    $params[] = $_GET['annee_id'];
                }
                
                $query .= " ORDER BY a.id DESC";
                $stmt = $db->prepare($query);
                $stmt->execute($params);
                echo json_encode($stmt->fetchAll());
            }
            break;

        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Insert
            // Generate simple matricule if not provided
            $matricule = (!empty($data['matricule'])) ? $data['matricule'] : 'MAT' . date('Y') . rand(1000, 9999);
            
            $stmt = $db->prepare("INSERT INTO apprenants (matricule, nom, prenom, date_naissance, sexe, telephone, adresse, filiere_id, niveau_id, annee_id, statut) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $matricule, $data['nom'], $data['prenom'], $data['date_naissance'], 
                $data['sexe'], $data['telephone'], $data['adresse'], $data['filiere_id'], 
                $data['niveau_id'], $data['annee_id'], $data['statut'] ?? 'Actif'
            ]);
            echo json_encode(['success' => true, 'message' => 'Apprenant ajouté avec succès.']);
            break;

        case 'PUT':
            $data = json_decode(file_get_contents('php://input'), true);
            if (isset($data['id'])) {
                $stmt = $db->prepare("UPDATE apprenants SET nom=?, prenom=?, date_naissance=?, sexe=?, telephone=?, adresse=?, filiere_id=?, niveau_id=?, annee_id=?, statut=? WHERE id=?");
                $stmt->execute([
                    $data['nom'], $data['prenom'], $data['date_naissance'], $data['sexe'], 
                    $data['telephone'], $data['adresse'], $data['filiere_id'], $data['niveau_id'], 
                    $data['annee_id'], $data['statut'], $data['id']
                ]);
                echo json_encode(['success' => true, 'message' => 'Apprenant modifié avec succès.']);
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'ID manquant']);
            }
            break;

        case 'DELETE':
            $data = json_decode(file_get_contents('php://input'), true);
            if (isset($data['id'])) {
                $stmt = $db->prepare("DELETE FROM apprenants WHERE id = ?");
                $stmt->execute([$data['id']]);
                echo json_encode(['success' => true, 'message' => 'Apprenant supprimé avec succès.']);
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'ID manquant']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Méthode non autorisée']);
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    if ($e->getCode() == 23000) { // Duplicate entry
        echo json_encode(['error' => 'Le matricule existe déjà.']);
    } else {
        echo json_encode(['error' => 'Erreur de base de données : ' . $e->getMessage()]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur : ' . $e->getMessage()]);
}
