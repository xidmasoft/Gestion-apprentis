# Document de Conception Technique - GESTION APPRENANTS (V1)

## 1. Architecture Générale
L'application repose sur une architecture client-serveur classique (SPA/Hybride) sans framework lourd, privilégiant la simplicité et la légèreté.
- **Frontend (Client)** : Interface utilisateur développée en HTML5, CSS3, et jQuery. Le frontend communique de manière asynchrone (AJAX) avec le backend pour offrir une expérience fluide sans rechargements de page fréquents.
- **Backend (Serveur)** : API RESTful simplifiée développée en PHP 8+. Le backend reçoit les requêtes HTTP, valide les données, exécute la logique métier et retourne les réponses au format JSON.
- **Base de données** : Serveur MySQL 8+ utilisant le moteur InnoDB pour garantir l'intégrité référentielle, avec un encodage `utf8mb4` pour un support complet des caractères (y compris les émojis et caractères spéciaux).

## 2. Modèle Relationnel
Le schéma de la base de données est composé de 4 tables principales avec les relations suivantes :
- `apprenants` est la table centrale.
- Une relation de type `1:N` entre `filieres` et `apprenants` (Une filière contient plusieurs apprenants).
- Une relation de type `1:N` entre `niveaux` et `apprenants` (Un niveau contient plusieurs apprenants).
- Une relation de type `1:N` entre `annees_formation` et `apprenants` (Une année de formation concerne plusieurs apprenants).

## 3. Structure SQL
Voici le script SQL de création de la structure de la base de données :

```sql
CREATE DATABASE IF NOT EXISTS gestion_apprenants CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gestion_apprenants;

CREATE TABLE filieres (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    description TEXT,
    actif BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE niveaux (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    description TEXT,
    actif BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE annees_formation (
    id INT AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(50) NOT NULL, -- Ex: "2026-2027"
    date_debut DATE,
    date_fin DATE,
    actif BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE apprenants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    matricule VARCHAR(50) NOT NULL UNIQUE,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    date_naissance DATE NOT NULL,
    sexe CHAR(1) NOT NULL, -- 'M' ou 'F'
    telephone VARCHAR(20),
    adresse TEXT,
    filiere_id INT NOT NULL,
    niveau_id INT NOT NULL,
    annee_id INT NOT NULL,
    statut VARCHAR(50) DEFAULT 'Actif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (filiere_id) REFERENCES filieres(id) ON DELETE RESTRICT,
    FOREIGN KEY (niveau_id) REFERENCES niveaux(id) ON DELETE RESTRICT,
    FOREIGN KEY (annee_id) REFERENCES annees_formation(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Index pour optimiser les recherches et les filtres
CREATE INDEX idx_apprenants_nom_prenom ON apprenants(nom, prenom);
CREATE INDEX idx_apprenants_statut ON apprenants(statut);
```

## 4. Architecture des Fichiers
La structure proposée sépare clairement les configurations, la logique backend, les vues frontend et les scripts d'initialisation :

```text
/
├── /config             # Configuration du projet
│   ├── database.php    # Connexion PDO
│   └── env.php         # Variables d'environnement (identifiants, etc.)
├── /api                # Backend (Endpoints PHP retournant du JSON)
│   ├── /apprenants
│   │   ├── create.php
│   │   ├── read.php
│   │   ├── update.php
│   │   └── delete.php
│   ├── /filieres
│   ├── /niveaux
│   └── /annees
├── /public             # Racine web (accessible par le navigateur)
│   ├── index.html      # Point d'entrée (Tableau de bord / Vue principale)
│   ├── /css
│   │   └── style.css
│   ├── /js
│   │   ├── app.js      # Logique principale jQuery/AJAX
│   │   └── api.js      # Fonctions d'appels API
│   └── /assets         # Images, icônes
└── /database           # Scripts SQL (Structure et seeders)
    └── schema.sql
```
*Justification de l'amélioration* : Séparer `/api` et `/public` permet de sécuriser le backend. L'utilisateur final n'accède qu'au contenu de `/public`, tandis que les scripts API sont appelés via des requêtes AJAX. Les fichiers de configuration (contenant les mots de passe) restent en dehors du dossier public.

## 5. Endpoints API
L'API RESTful respectera les conventions suivantes, en utilisant le format JSON pour les échanges :

**Apprenants (`/api/apprenants/...`)**
- `GET read.php` : Liste tous les apprenants (accepte des paramètres GET pour la recherche et les filtres).
- `GET read.php?id={id}` : Détails d'un apprenant spécifique.
- `POST create.php` : Ajoute un nouvel apprenant (Données dans le body).
- `POST update.php` (ou PUT/PATCH géré via POST) : Met à jour un apprenant.
- `POST delete.php` : Supprime un apprenant.

**Référentiels (`/api/filieres/...`, `/api/niveaux/...`, `/api/annees/...`)**
- `GET read.php` : Liste les éléments actifs.
- `POST create.php` : Ajoute un élément.
- `POST update.php` : Modifie un élément (ou le désactive en passant `actif=0`).

## 6. Flux Frontend/Backend
1. **Initialisation** : Au chargement de `index.html`, jQuery effectue des requêtes AJAX (`GET /api/filieres/read.php`, etc.) pour peupler les listes déroulantes des filtres et du formulaire.
2. **Recherche/Filtrage** : L'utilisateur saisit un texte ou choisit un filtre. jQuery intercepte l'événement (`keyup`, `change`) et envoie une requête AJAX `GET /api/apprenants/read.php?search=...&filiere=...`. Le serveur retourne la liste filtrée en JSON, et jQuery met à jour le tableau HTML.
3. **Création/Modification** : Soumission du formulaire (interceptée par `e.preventDefault()`). Validation locale, puis envoi AJAX POST avec sérialisation des données. Le serveur valide, enregistre, et répond par un statut (200 OK ou 400 Bad Request). jQuery affiche le message d'état (Succès/Erreur) et rafraîchit le tableau.

## 7. Maquettes fonctionnelles simples (Wireframes textuels)

- **Tableau de bord (Vue principale)** :
  - **En-tête** : Titre "Gestion Apprenants", bouton "Nouvel Apprenant".
  - **Barre d'outils** : 
    - Champ texte : "Rechercher par matricule, nom..."
    - Menus déroulants (Filtres) : "Toutes les filières", "Tous les niveaux", "Toutes les années".
  - **Tableau de données** :
    - Colonnes : Matricule, Nom, Prénom, Filière, Niveau, Statut, Actions.
    - Actions : Boutons [Détails] [Modifier] [Supprimer] sur chaque ligne.

- **Modale / Formulaire Apprenant** :
  - Champs : Matricule (généré ou saisi), Nom, Prénom, Date de Naissance (Datepicker), Sexe (Boutons radio), Téléphone, Adresse, Filière (Select), Niveau (Select), Année (Select), Statut.
  - Boutons : [Annuler] [Enregistrer].

- **Messages d'état (Toasts/Alerts)** :
  - Affichage flottant en haut à droite (Vert pour succès, Rouge pour erreur) disparaissant après 3 secondes.

## 8. Règles de sécurité
- **Base de données** : 
  - Utilisation exclusive de **PDO** et des **requêtes préparées** (avec bindParam/bindValue) pour empêcher toute injection SQL.
- **Validation Serveur (PHP)** : 
  - Nettoyage et validation systématique de toutes les données entrantes (`filter_input`, expressions régulières pour le téléphone/date). On ne fait jamais confiance au client.
- **Validation Frontend (JS/HTML5)** : 
  - Attributs `required`, `type="date"`, `pattern` côté HTML. Vérifications de cohérence en jQuery avant l'envoi AJAX.
- **Protection XSS** : 
  - Bien que l'API renvoie du JSON, le frontend échappera les données lors de leur insertion dans le DOM (utilisation de `.text()` plutôt que `.html()` dans jQuery).
- **Gestion des erreurs** : 
  - En mode production, aucune erreur PHP/SQL n'est affichée au client. L'API retourne des messages d'erreur génériques en JSON (ex: `{"error": "Erreur interne du serveur"}`).
- **Protection des identifiants** : 
  - Le fichier `/config/database.php` sera protégé par un `.htaccess` (si Apache) ou placé en dehors de la racine publique.

## 9. Stratégie de tests
Avant et pendant le développement :
- **Tests unitaires (Manuel/Postman)** : Tester indépendamment chaque endpoint de l'API (`create.php`, `read.php`) en simulant des requêtes valides et invalides (tests de limites) via Postman ou curl.
- **Tests d'intégration** : Vérifier que l'interface jQuery communique correctement avec l'API, que les JSON reçus sont correctement parsés et affichés.
- **Tests fonctionnels (E2E)** : Simuler le parcours utilisateur complet :
  1. Créer une filière, un niveau, une année.
  2. Créer un apprenant en vérifiant les règles métier (matricule unique).
  3. Effectuer une recherche et appliquer des filtres.
  4. Modifier puis supprimer l'apprenant.
- **Tests de sécurité** : Tenter d'injecter du code SQL dans le formulaire de recherche et des balises `<script>` dans les champs textuels pour vérifier la robustesse.